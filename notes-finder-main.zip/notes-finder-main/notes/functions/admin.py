from django.contrib import admin
from .models import Contact,AI,JAVA
from .models import SE,PD,IME,DM
from .models import DS,SD,NS
# Register your models here.
admin.site.register(Contact)
admin.site.register(AI)
admin.site.register(JAVA)
admin.site.register(SE)
admin.site.register(PD)
admin.site.register(IME)
admin.site.register(DM)
admin.site.register(DS)
admin.site.register(SD)
admin.site.register(NS)

